# Automated Error Dection
## Duplicate Route (12)
* Duplicate Destination route to WOODFORD using the CENTRAL train line
* Duplicate Destination route to LEYTONSTONE using the CENTRAL train line
* Duplicate Destination route to CHALFONT & LATIMER using the METROPOLITAN train line
* Duplicate Destination route to MOOR PARK using the METROPOLITAN train line
* Duplicate Destination route to HARROW-ON-THE-HILL using the METROPOLITAN train line
* Duplicate Destination route to WEMBLEY PARK using the METROPOLITAN train line
* Duplicate Destination route to FINCHLEY ROAD using the METROPOLITAN train line
* Duplicate Destination route to FINCHLEY CENTRAL using the NORTHERN train line
* Duplicate Destination route to CAMDEN TOWN using the NORTHERN train line
* Duplicate Destination route to EUSTON using the NORTHERN train line
* Duplicate Destination route to KENNINGTON using the NORTHERN train line
* Duplicate Destination route to ACTON TOWN using the PICCADILLY train line
## EXTREME VALUE (2)
* Extreme value '16' detected from HARROW-ON-THE-HILL to FINCHLEY ROAD using the METROPOLITAN train line
* Extreme value '14' detected from MOOR PARK to HARROW-ON-THE-HILL using the METROPOLITAN train line
## MISSING TRAIN LINE (1)
* Train line not provided on row 210