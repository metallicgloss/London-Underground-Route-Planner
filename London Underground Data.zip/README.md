# COMP1828-Coursework

[![Build Status](https://travis-ci.com/metallicgloss/COMP1828-Coursework.svg?token=qhe4xK4Y5TeknywzyUwA&branch=main)](https://travis-ci.com/metallicgloss/COMP1828-Coursework)
